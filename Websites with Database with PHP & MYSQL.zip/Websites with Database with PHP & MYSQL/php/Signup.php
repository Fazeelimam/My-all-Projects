<?php
session_start();
include('config.php');
if(isset($_POST['btn']))
{
   $name= $_POST['name'];
   $email= $_POST['email'];
   $password= $_POST['password'];
   $cpassword= $_POST['cpassword'];

   $query1="select Email from user where Email = '$email' ";
   $res=mysqli_query($con,$query1);
   if(mysqli_num_rows($res) > 0)
   {
    echo "<script>alert('This Email is already Taken')
    window.location.href='Signup.php'
    </script>";
   }
   else
   {
    $query="INSERT INTO user (name,Email,password,cpassword) values ('$name','$email','$password','$cpassword')";
    $res=mysqli_query($con,$query);
    if($res)
    {
      echo "<script>alert('Signup Successfully')
      window.location.href='login.php'
      </script>";
    }
  
    else
    {
      echo "<script>alert('Failed')
      window.location.href='Signup.php'
      </script>";
    }
   }

}






?>
<!DOCTYPE html>
<html>
<head>
  <!-- Basic -->
  <meta charset="utf-8" />
  <meta http-equiv="X-UA-Compatible" content="IE=edge" />
  <!-- Mobile Metas -->
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no" />
  <!-- Site Metas -->
  <meta name="keywords" content="" />
  <meta name="description" content="" />
  <meta name="author" content="" />
  <link rel="shortcut icon" href="images/favicon.png" type="">

  <title> Crypto Currency </title>

  <!-- bootstrap core css -->
  <link rel="stylesheet" type="text/css" href="css/bootstrap.css" />

  <!-- fonts style -->
  <link href="https://fonts.googleapis.com/css2?family=Roboto:wght@400;500;700;900&display=swap" rel="stylesheet">

  <!--owl slider stylesheet -->
  <link rel="stylesheet" type="text/css" href="https://cdnjs.cloudflare.com/ajax/libs/OwlCarousel2/2.3.4/assets/owl.carousel.min.css" />

  <!-- font awesome style -->
  <link href="css/font-awesome.min.css" rel="stylesheet" />

  <!-- Custom styles for this template -->
  <link href="css/style.css" rel="stylesheet" />
  <!-- responsive style -->
  <link href="css/responsive.css" rel="stylesheet" />

</head>
<body>
<div class="conatiner  m-auto shadow-lg p-5  col-md-6">
    <form action="Signup.php" name="abc" method="POST">
    <div class="text-center"><h1>Sign In</h1></div>
    
        <input  type="text" name="name" placeholder="Enter Your Name" class="form-control mt-3" required required>
    
        <input  type="email" name="email" placeholder="Enter Your Email" 
         pattern="[a-z0-9._%+\-]+@[a-z0-9.\-]+\.[a-z]{2,}$" class="form-control mt-3" required required>
    
        <input  type="password" name="password" id="pass" placeholder="Enter Your Password" 
        pattern="(?=.*\d)(?=.*[a-z])(?=.*[A-Z]).{8,}" title="Must contain at least one number and one uppercase and lowercase letter,
         and at least 8 or more characters" class="form-control mt-3" required required>
  
        <input  type="password" name="cpassword" id="cpass" placeholder="Confirm Password" class="form-control mt-3" required>

    <label for="#">Show password</label>
    <input type="checkbox" onclick='show()'><br>

    <input type="submit" name='btn' onclick='return check()' value="Signup" class="btn btn-primary btn-block mt-3">

    <div class="login-register">
                 <p>Already Have a account?<a href="Login.php" class="Register-link">Login</a> </p>
                </div>

                <div class="login-register">
                 <p>Change Password?<a href="changepass.php" class="Register-link">Change Password</a> </p>
                </div>

    </form>
</div>

<script>
  function show(){
    var pass = document.getElementById("pass");
    var cpass = document.getElementById("cpass");
    if (pass.type === "password" && cpass.type === "password"){
      pass.type= 'text';
      cpass.type= 'text';
    }
    else{
      pass.type = 'password';
      cpass.type = 'password';
    }
  }

  function check(){
    var pass = abc.pass.value;
    var cpass = abc.cpass.value;
    if(password!=cpassword){
      alert('Passwords do not match');
      return false;
    }
  }
</script>

<script type="text/javascript" src="js/jquery-3.4.1.min.js"></script>
  <!-- popper js -->
  <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.0/dist/umd/popper.min.js" integrity="sha384-Q6E9RHvbIyZFJoft+2mJbHaEWldlvI9IOYy5n3zV9zzTtmI3UksdQRVvoxMfooAo" crossorigin="anonymous">
  </script>
  <!-- bootstrap js -->
  <script type="text/javascript" src="js/bootstrap.js"></script>
  <!-- owl slider -->
  <script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/OwlCarousel2/2.3.4/owl.carousel.min.js">
  </script>
  <!-- custom js -->
  <script type="text/javascript" src="js/custom.js"></script>
  <!-- Google Map -->
  <script src="https://maps.googleapis.com/maps/api/js?key=AIzaSyCh39n5U-4IoWpsVGUHWdqB6puEkhRLdmI&callback=myMap">
  </script>
  <!-- End Google Map -->
</body>
</html>