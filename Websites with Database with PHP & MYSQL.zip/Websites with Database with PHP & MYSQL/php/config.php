<?php
define("HOSTNAME","LOCALHOST");
define("USERNAME","root");
define("PASSWORD","");
define("DBNAME","data");

$con=mysqli_connect(HOSTNAME,USERNAME,PASSWORD,DBNAME);
?>