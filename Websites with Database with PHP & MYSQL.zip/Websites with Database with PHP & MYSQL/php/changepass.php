<!DOCTYPE html>
<html>
<head>
  <!-- Basic -->
  <meta charset="utf-8" />
  <meta http-equiv="X-UA-Compatible" content="IE=edge" />
  <!-- Mobile Metas -->
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no" />
  <!-- Site Metas -->
  <meta name="keywords" content="" />
  <meta name="description" content="" />
  <meta name="author" content="" />
  <link rel="shortcut icon" href="images/favicon.png" type="">

  <title> Crypto Currency </title>

  <!-- bootstrap core css -->
  <link rel="stylesheet" type="text/css" href="css/bootstrap.css" />

  <!-- fonts style -->
  <link href="https://fonts.googleapis.com/css2?family=Roboto:wght@400;500;700;900&display=swap" rel="stylesheet">

  <!--owl slider stylesheet -->
  <link rel="stylesheet" type="text/css" href="https://cdnjs.cloudflare.com/ajax/libs/OwlCarousel2/2.3.4/assets/owl.carousel.min.css" />

  <!-- font awesome style -->
  <link href="css/font-awesome.min.css" rel="stylesheet" />

  <!-- Custom styles for this template -->
  <link href="css/style.css" rel="stylesheet" />
  <!-- responsive style -->
  <link href="css/responsive.css" rel="stylesheet" />

</head>
<body>
<div class="conatiner m-auto shadow-lg p-5  col-md-6">
    <form action="changepass.php" method="POST">
        <h2 class="text-center">Update Password</h2>
   
        <input type="password" name="oldpassword" id="" placeholder="Enter Your Old Password" class="form-control mt-3" required>
  
        <input  type="password" name="newpassword" id="" placeholder="Enter Your New Password" class="form-control mt-3" required>
   
        <input  type="password" name="confirmpassword" id="" placeholder="Confirm Password" class="form-control mt-3" required>
  
    <input type="submit" name='btn'  value="Change Password" class="btn btn-primary btn-block mt-3">
    </form>
</div>


<?php
include('config.php');
session_start();
if(isset($_POST['btn']))
{
    if(isset($_SESSION['name']))
    {
        $name=$_SESSION['name'];
        // echo $name;
       $query= "select * from user where name = '$name'";
       $res=mysqli_query($con,$query);
      $data= mysqli_fetch_assoc($res);
    //   print_r($data);
    $oldpassword=$data['password'];
    $id=$data['id'];

    $oldpassword=$_POST['oldpassword'];
    $newpassword=$_POST['newpassword'];
    $confirmpassword=$_POST['confirmpassword'];
if($oldpassword == $oldpassword)
{
  if($newpassword == $confirmpassword)
  {
     $query1="update user set password = '$newpassword' , cpassword = '$newpassword' where id = '$id'";
     $res=mysqli_query($con,$query1);
     if($res)
     {
        echo "<script>alert('password Updated Successfully')</script>";
     }
     else
     {
        echo "<script>alert('Cant update password')</script>";
     }
  }

  else
  {
    echo "<script>alert('password and confirm password should be identical')</script>";
  }
}
else
{
    echo "<script>alert('Invalid Curtrent password')</script>";
}


    }
}




?>



<script type="text/javascript" src="js/jquery-3.4.1.min.js"></script>
  <!-- popper js -->
  <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.0/dist/umd/popper.min.js" integrity="sha384-Q6E9RHvbIyZFJoft+2mJbHaEWldlvI9IOYy5n3zV9zzTtmI3UksdQRVvoxMfooAo" crossorigin="anonymous">
  </script>
  <!-- bootstrap js -->
  <script type="text/javascript" src="js/bootstrap.js"></script>
  <!-- owl slider -->
  <script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/OwlCarousel2/2.3.4/owl.carousel.min.js">
  </script>
  <!-- custom js -->
  <script type="text/javascript" src="js/custom.js"></script>
  <!-- Google Map -->
  <script src="https://maps.googleapis.com/maps/api/js?key=AIzaSyCh39n5U-4IoWpsVGUHWdqB6puEkhRLdmI&callback=myMap">
  </script>
  <!-- End Google Map -->
</body>
</html>